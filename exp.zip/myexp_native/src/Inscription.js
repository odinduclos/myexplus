import React, { Component, PropTypes } from 'react';
import { View, Text, TouchableHighlight, Html5, ScrollView, StyleSheet, ListView, Image, TextInput, Alert } from 'react-native';
import Button from 'react-native-button';
import HeaderInscription from './components/HeaderInscription';
export default class Inscription extends Component {
	constructor(props) {
		super(props);
		this.state = {
			firstname: '',
			lastname: '',
			mail: '',
			password: '',
			password_confirm: '',
		};
	}

	Register() {
		if (this.state.password == this.state.password_confirm) {
			fetch('http://164.132.230.151/utilisateurs/new', {
				method: 'post',
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					prenom: this.state.firstname,
					nom: this.state.lastname,
					mail: this.state.mail,
					password_hash: this.state.password,
				})
			})
			.then((response) => response.json())
			.then((data) => {
				if (data.message_err == undefined) {
					this.props.onBack();
				}
				console.warn(data.message_err);
			})
			.catch((error) => {
				console.warn(error, "Pas de chance LOL");
			});	
		}
	}

	render() {
		return (
			<View style={styles.container}>
			<HeaderInscription />
			<View style={{backgroundColor: 'white', alignItems: "center"}}>
			<TextInput
			onChangeText={(text) => this.setState({firstname: text})}
			value={this.state.firstname}
			style={styles.input}
			placeholder="Votre prénom"
			underlineColorAndroid= {'transparent'}
			/>
			<TextInput
			onChangeText={(text) => this.setState({lastname: text})}
			value={this.state.lastname}
			style={styles.input}
			placeholder="Votre nom"
			underlineColorAndroid= {'transparent'}
			/>
			<TextInput
			onChangeText={(text) => this.setState({mail: text})}
			value={this.state.mail}
			style={styles.input}
			placeholder="Votre adresse mail"
			underlineColorAndroid= {'transparent'}
			/>
			<TextInput
			onChangeText={(text) => this.setState({password: text})}
			secureTextEntry={true}
			value={this.state.password}
			style={styles.input}
			placeholder="Votre mot de passe"
			underlineColorAndroid= {'transparent'}
			/>
			<TextInput
			onChangeText={(text) => this.setState({password_confirm: text})}
			secureTextEntry={true}
			value={this.state.password_confirm}
			style={styles.input}
			placeholder="Confirmez votre mot de passe"
			underlineColorAndroid= {'transparent'}
			/>
			<View style={{ justifyContent: "center", width: 275,  marginTop: 20 }}>
				<Text style={{ fontFamily: 'raleway_bold', fontSize: 13, color: "#8C8C8C" }}>
				Un mail de confirmation vous sera envoyé, après quoi vous pourrez vous connecter.
				</Text>
			</View>
			</View>
			<View style={{backgroundColor: 'white', width: 292, marginBottom: 20 }}>
			<Button onPress={(this.Register.bind(this))}
			containerStyle={{padding:11, height:45, overflow:'hidden', borderRadius:22, backgroundColor: '#093996'}}
			style={{fontSize: 15, color: 'white'}}>
			Inscription
			</Button>
			<TouchableHighlight style={{ alignItems: "center", marginTop: 15 }} onPress={this.props.onBack}>
			<Text style={styles.underlineText} >Déjà un compte ? Connectez vous.</Text>
			</TouchableHighlight>
			</View>
			</View>
			)
	}
}


const onButtonPress = () => { Alert.alert('Button has been pressed!'); };

const styles = StyleSheet.create({
	container: {
		margin: 0,
		padding: 0,
		justifyContent: "center",
		backgroundColor: "white",
		flex: 1,
		justifyContent: "space-between",
		flexDirection: 'column',
		alignItems: 'center',
	},
	title: {
		fontSize: 30,
	},
	input: {
		width: 300,
		marginTop: 20,
		backgroundColor: "#E6E6E6",
		borderRadius: 2,
		height: 40,
		paddingLeft: 10,
		fontFamily: 'raleway_bold',

	},
	button: {
		color: "#333333",
		padding: 30,
		backgroundColor: "#00379b",
		borderRadius: 10,
	},
	underlineText: {
		textDecorationLine: "underline",
		textDecorationStyle: "solid",
		textDecorationColor: "#00379b",
		color: '#b45596',
		fontFamily: 'raleway_bold',
		fontSize: 15,
	}
});

Inscription.propTypes = {
	title: PropTypes.string.isRequired,
	onForward: PropTypes.func.isRequired,
	onBack: PropTypes.func.isRequired,
};
